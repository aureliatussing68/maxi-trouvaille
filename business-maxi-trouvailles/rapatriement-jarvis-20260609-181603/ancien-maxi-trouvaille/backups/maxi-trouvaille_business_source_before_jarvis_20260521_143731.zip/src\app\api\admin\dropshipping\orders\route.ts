import { NextResponse } from "next/server";
import { isAdminModeEnabled } from "@/lib/admin";
import { readDropshippingOrders } from "@/lib/dropshipping-server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  if (!isAdminModeEnabled()) {
    return NextResponse.json({ error: "Mode admin desactive." }, { status: 403 });
  }

  return NextResponse.json({ orders: await readDropshippingOrders() });
}
