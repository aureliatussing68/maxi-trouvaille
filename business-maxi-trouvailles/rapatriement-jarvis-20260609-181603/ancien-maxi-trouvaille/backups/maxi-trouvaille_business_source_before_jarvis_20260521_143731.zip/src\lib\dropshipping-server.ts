import { promises as fs } from "fs";
import path from "path";
import { isDropshippingProduct, type Product } from "@/lib/catalog";
import type { ShippingValidationResult } from "@/lib/shipping";
import {
  dropshippingStatusLabels,
  sanitizeDropshippingStatus,
  type DropshippingOrder,
  type DropshippingOrderStatus,
} from "@/lib/dropshipping-shared";

const dropshippingOrdersPath = path.join(
  process.cwd(),
  "data",
  "dropshipping-orders.json",
);

type PaidShippingValidation = Extract<ShippingValidationResult, { ok: true }>;

type CartLine = {
  productId: string;
  quantity: number;
};

export async function readDropshippingOrders(): Promise<DropshippingOrder[]> {
  try {
    const content = await fs.readFile(dropshippingOrdersPath, "utf8");
    const parsed = JSON.parse(content) as unknown;
    return Array.isArray(parsed) ? (parsed as DropshippingOrder[]) : [];
  } catch {
    return [];
  }
}

export async function writeDropshippingOrders(orders: DropshippingOrder[]) {
  await fs.mkdir(path.dirname(dropshippingOrdersPath), { recursive: true });
  await fs.writeFile(
    dropshippingOrdersPath,
    JSON.stringify(orders, null, 2),
    "utf8",
  );
}

function createOrderNumber() {
  const date = new Date();
  const day = date.toISOString().slice(0, 10).replace(/-/g, "");
  const suffix = Math.random().toString(36).slice(2, 7).toUpperCase();
  return `MT-DROP-${day}-${suffix}`;
}

function getQuantity(productId: string, cartLines: CartLine[]) {
  return cartLines.find((line) => line.productId === productId)?.quantity ?? 1;
}

export async function recordDropshippingCheckoutDraft({
  stripeSessionId,
  products,
  cartLines,
  shippingValidation,
}: {
  stripeSessionId: string;
  products: Product[];
  cartLines: CartLine[];
  shippingValidation: PaidShippingValidation;
}) {
  const dropshippingProducts = products.filter(isDropshippingProduct);

  if (dropshippingProducts.length === 0) {
    return null;
  }

  const orders = await readDropshippingOrders();
  const existing = orders.find((order) => order.stripeSessionId === stripeSessionId);

  if (existing) {
    return existing;
  }

  const now = new Date().toISOString();
  const lines = dropshippingProducts.map((product) => {
    const quantity = getQuantity(product.id, cartLines);
    const supplierPriceCents = product.dropshipping?.supplierPriceCents ?? 0;
    const soldPriceCents = product.price;
    const marginCents =
      product.dropshipping?.marginCents ?? Math.max(0, soldPriceCents - supplierPriceCents);

    return {
      productId: product.id,
      productSlug: product.slug,
      productName: product.name,
      image: product.image,
      quantity,
      supplierName: product.dropshipping?.supplierName ?? "Fournisseur partenaire",
      supplierUrl: product.dropshipping?.supplierUrl ?? "",
      supplierSku: product.dropshipping?.supplierSku ?? "",
      supplierPriceCents,
      soldPriceCents,
      marginCents,
      supplierStock: product.dropshipping?.supplierStock,
      deliveryEstimate: product.dropshipping?.deliveryEstimate ?? "8 a 15 jours ouvres",
    };
  });

  const supplierTotalCents = lines.reduce(
    (total, line) => total + line.supplierPriceCents * line.quantity,
    0,
  );
  const soldTotalCents = lines.reduce(
    (total, line) => total + line.soldPriceCents * line.quantity,
    0,
  );

  const customer = shippingValidation.selection.customer;
  const order: DropshippingOrder = {
    id: `drop_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    orderNumber: createOrderNumber(),
    stripeSessionId,
    paymentStatus: "stripe-session-created",
    status: "a-traiter",
    customer: {
      name: `${customer.firstName} ${customer.lastName}`.trim(),
      email: customer.email,
      phone: customer.phone,
    },
    shippingAddress: {
      street: customer.street,
      postalCode: customer.postalCode,
      city: customer.city,
      country: "France",
      methodLabel: shippingValidation.method.label,
    },
    lines,
    supplierTotalCents,
    soldTotalCents,
    estimatedMarginCents: Math.max(0, soldTotalCents - supplierTotalCents),
    shippingPriceCents: shippingValidation.method.price,
    internalNote:
      "Commande fournisseur a valider manuellement. Aucun achat fournisseur automatique n'est execute.",
    createdAt: now,
    updatedAt: now,
  };

  await writeDropshippingOrders([order, ...orders]);
  return order;
}

export async function markDropshippingOrderPaid(stripeSessionId: string) {
  const orders = await readDropshippingOrders();
  let updatedOrder: DropshippingOrder | null = null;
  const updatedOrders = orders.map((order) => {
    if (order.stripeSessionId !== stripeSessionId) {
      return order;
    }

    updatedOrder = {
      ...order,
      paymentStatus: "paid",
      updatedAt: new Date().toISOString(),
    };
    return updatedOrder;
  });

  if (updatedOrder) {
    await writeDropshippingOrders(updatedOrders);
  }

  return updatedOrder;
}

export async function updateDropshippingOrder(
  orderId: string,
  patch: {
    status?: DropshippingOrderStatus;
    trackingNumber?: string;
    supplierOrderReference?: string;
    internalNote?: string;
    followUpMessagePreparedAt?: string;
  },
) {
  const orders = await readDropshippingOrders();
  let updatedOrder: DropshippingOrder | null = null;
  const updatedOrders = orders.map((order) => {
    if (order.id !== orderId) {
      return order;
    }

    const status = patch.status
      ? sanitizeDropshippingStatus(patch.status)
      : order.status;

    updatedOrder = {
      ...order,
      status,
      trackingNumber: patch.trackingNumber ?? order.trackingNumber,
      supplierOrderReference:
        patch.supplierOrderReference ?? order.supplierOrderReference,
      internalNote: patch.internalNote ?? order.internalNote,
      followUpMessagePreparedAt:
        patch.followUpMessagePreparedAt ?? order.followUpMessagePreparedAt,
      updatedAt: new Date().toISOString(),
    };

    return updatedOrder;
  });

  if (!updatedOrder) {
    return null;
  }

  await writeDropshippingOrders(updatedOrders);
  return updatedOrder;
}

export function getDropshippingConnectorStatus() {
  return [
    {
      name: "Stripe",
      ready: Boolean(process.env.STRIPE_SECRET_KEY),
      detail: "Paiement client et webhook commandes",
    },
    {
      name: "AliExpress API / Affiliate",
      ready: Boolean(process.env.ALIEXPRESS_API_KEY),
      detail: "Import et synchronisation prix/stock future",
    },
    {
      name: "DSers",
      ready: Boolean(process.env.DSERS_API_KEY),
      detail: "Espace de connexion pret a renseigner si compte disponible",
    },
    {
      name: "AutoDS",
      ready: Boolean(process.env.AUTODS_API_KEY),
      detail: "Espace de connexion pret a renseigner si compte disponible",
    },
  ];
}

export function getDropshippingStatusLabel(status: DropshippingOrderStatus) {
  return dropshippingStatusLabels[status];
}
