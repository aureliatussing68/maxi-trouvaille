import type { Metadata } from "next";
import { PageHeader } from "@/components/PageHeader";
import { TrackingLookupForm } from "@/components/TrackingLookupForm";

export const metadata: Metadata = {
  title: "Suivi colis",
  description:
    "Suivre une commande Maxi Trouvaille avec son numero de suivi colis.",
};

export default function TrackingPage() {
  return (
    <>
      <PageHeader
        eyebrow="Suivi colis"
        title="Suivi de commande"
        description="Retrouvez les informations de livraison dès que Maxi Trouvaille ajoute le numéro de suivi."
      />
      <section className="container-page py-10">
        <TrackingLookupForm />
      </section>
    </>
  );
}
